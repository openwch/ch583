package cn.wch.wchiochubgwtest.bean;

import java.util.List;

public class IoCHubSessionBean {
    private final int sessionFD;  //会话句柄
    private final String nodeID;  //对端节点ID
    private boolean isSessionException;  //会话状态
    private int sessionType;             //会话类型


    public IoCHubSessionBean(int fd, String id){
        this.sessionFD = fd;
        this.nodeID = id;
        this.isSessionException = true;
    }

    public int getSessionFD() {
        return sessionFD;
    }

    public String getNodeID() {
        return nodeID;
    }

    public boolean isSessionException() {
        return isSessionException;
    }

    public void setSessionException(boolean sessionException) {
        isSessionException = sessionException;
    }

    public int getSessionType() {
        return sessionType;
    }

    public void setSessionType(int sessionType) {
        this.sessionType = sessionType;
    }


}
