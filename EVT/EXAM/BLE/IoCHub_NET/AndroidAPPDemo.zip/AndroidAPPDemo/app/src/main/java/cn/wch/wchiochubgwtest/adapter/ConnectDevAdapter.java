package cn.wch.wchiochubgwtest.adapter;

import static cn.wch.wchiochubgwtest.Global.DEVICE_CMD_LIGHT;
import static cn.wch.wchiochubgwtest.Global.DEVICE_CMD_SOCKET;
import static cn.wch.wchiochubgwtest.Global.DEVICE_TYPE_BLE;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import java.util.Locale;

import cn.wch.wchiochubgwtest.R;
import cn.wch.wchiochubgwtest.bean.DeviceInfoBean;

public class ConnectDevAdapter extends RecyclerView.Adapter<ConnectDevAdapter.ViewHolder> {

    private List<DeviceInfoBean> deviceInfoBeanList;
    private ConnectDevAdapterCallback connectDevAdapterCallback;
    public ConnectDevAdapter(List<DeviceInfoBean> list  ,ConnectDevAdapterCallback callback){
        deviceInfoBeanList = list;
        connectDevAdapterCallback = callback;
    }
    @NonNull
    @Override
    public ConnectDevAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.dev_info_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        DeviceInfoBean deviceInfoBean = deviceInfoBeanList.get(position);
        int type = deviceInfoBean.getType();
        if (type == DEVICE_TYPE_BLE){
            holder.typeText.setText("蓝牙");
        }else {
            holder.typeText.setText("未知");
        }
        String mac = deviceInfoBean.getMac();
        if (mac != null){
            holder.macText.setText(mac);
        }
        if (deviceInfoBean.isLightState()){
            holder.lightStateImage.setImageResource(R.drawable.ic_light_open);
            holder.lightEnableText.setText("关闭");
        }else {
            holder.lightStateImage.setImageResource(R.drawable.ic_light_close);
            holder.lightEnableText.setText("打开");
        }
        if(deviceInfoBean.isSocketState()){
            holder.socketStateText.setText("开启");
        }else {
            holder.socketStateText.setText("关闭");
        }

        holder.lightEnableText.setOnClickListener(v -> {
            if (holder.lightEnableText.getText().equals("打开")){
                if (connectDevAdapterCallback != null){
                    connectDevAdapterCallback.onEnableLightState(mac,true);
                }
            }else {
                if (connectDevAdapterCallback != null){
                    connectDevAdapterCallback.onEnableLightState(mac,false);
                }
            }
        });


    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position, @NonNull List<Object> payloads) {
        if(payloads.isEmpty()){
            onBindViewHolder(holder,position);
        }else {
            if (payloads.get(0) != null){
                DeviceState deviceState = (DeviceState) payloads.get(0);
                int type = deviceState.getType();
                if (type == DEVICE_CMD_LIGHT){
                    if (deviceState.isState()){
                        holder.lightStateImage.setImageResource(R.drawable.ic_light_open);
                        holder.lightEnableText.setText("关闭");
                    }else {
                        holder.lightStateImage.setImageResource(R.drawable.ic_light_close);
                        holder.lightEnableText.setText("打开");
                    }

                } else if (type == DEVICE_CMD_SOCKET) {
                    if(deviceState.isState()){
                        holder.socketStateText.setText("开启");
                    }else {
                        holder.socketStateText.setText("关闭");
                    }
                }
            }
        }
    }

    //更新设备状态
    public void updateState(String mac,int type,boolean state){
        for (int i = 0;i<deviceInfoBeanList.size();i++){
            if(deviceInfoBeanList.get(i).getMac().equals(mac)){
                notifyItemChanged(i,new DeviceState(type,state) );
            }
        }

    }

    @Override
    public int getItemCount() {
        return deviceInfoBeanList.size();
    }

    private class DeviceState{
        private int type;
        private boolean state;

        private DeviceState(int type, boolean state) {
            this.type = type;
            this.state = state;
        }

        public int getType() {
            return type;
        }

        public boolean isState() {
            return state;
        }
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView typeText,nameText,macText,socketStateText,lightEnableText;
        ImageView lightStateImage;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            typeText = itemView.findViewById(R.id.type_text);
            nameText = itemView.findViewById(R.id.name_text);
            macText = itemView.findViewById(R.id.mac_text);
            socketStateText = itemView.findViewById(R.id.socket_state_text);
            lightEnableText = itemView.findViewById(R.id.light_enable_text);
            lightStateImage = itemView.findViewById(R.id.light_state_image);

        }
    }

    public interface ConnectDevAdapterCallback{
        void onEnableLightState(String mac,boolean state);
    }

}
