package cn.wch.wchiochubgwtest.util;

import android.util.Log;

public class LogUtil {
    private static final boolean isDebug = true;
    private static final String TAG = "WCHIoCHubGWTest";

    public static void d(String message){
        if (isDebug){
            Log.d(TAG,message);
        }
    }
}
