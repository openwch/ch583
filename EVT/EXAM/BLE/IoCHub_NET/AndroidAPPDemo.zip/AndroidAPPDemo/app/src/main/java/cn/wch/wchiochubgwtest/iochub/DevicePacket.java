package cn.wch.wchiochubgwtest.iochub;

public class DevicePacket {
    private final int dpId;
    private final int dpType;
    private final int dpLength;
    private final byte[] dpValue;
    private final int checksum;

    public DevicePacket(int dpId, int dpType, int dpLength, byte[] dpValue, int checksum) {
        this.dpId = dpId;
        this.dpType = dpType;
        this.dpLength = dpLength;
        this.dpValue = dpValue;
        this.checksum = checksum;
    }

    public int getDpId() {
        return dpId;
    }

    public int getDpType() {
        return dpType;
    }

    public int getDpLength() {
        return dpLength;
    }

    public byte[] getDpValue() {
        return dpValue;
    }

    public int getChecksum() {
        return checksum;
    }
}
