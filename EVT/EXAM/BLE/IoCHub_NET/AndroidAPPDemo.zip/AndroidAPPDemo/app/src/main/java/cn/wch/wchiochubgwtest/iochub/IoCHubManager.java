package cn.wch.wchiochubgwtest.iochub;

import android.content.Context;


import cn.wch.iochublibrary.WCHIoCHubManager;
import cn.wch.iochublibrary.callback.EventListener;
import cn.wch.iochublibrary.config.AccessMode;
import cn.wch.iochublibrary.config.InitConfig;
import cn.wch.iochublibrary.error.IoCHubException;
import cn.wch.wchiochubgwtest.assist.CurrentSessionAssist;
import cn.wch.wchiochubgwtest.bean.IoCHubSessionBean;
import cn.wch.wchiochubgwtest.callback.IoCHubConnectStatus;
import cn.wch.wchiochubgwtest.callback.SessionDataCallback;
import cn.wch.wchiochubgwtest.util.FormatUtil;
import cn.wch.wchiochubgwtest.util.LogUtil;

public class IoCHubManager {
    private static final String SERVER_ADDR = "58.213.74.190:38089";
    private static IoCHubConnectStatus ioCHubConnectStatus;
    private static SessionDataCallback sessionDataCallback;


    /**
     * IoCHub各类信息汇集中心
     */

    //初始化  满足启动前要求
    public static int initIoCHub(Context context){
        int code  = -1;
        //初始化
        code = WCHIoCHubManager.getInstance().init(context);
//        //设置模式
//        AccessMode accessMode;
//        if (ConfigSaveUtil.getInstance().getCurrentDebugMode() == REMOTE_DEBUG){
//            accessMode = new AccessMode(0,SESSION_KEY_REMOTE_DEBUG);
//        } else {
//            accessMode = new AccessMode(0,SESSION_KEY_REMOTE_RELAY);
//        }
//        WCHIoCHubManager.getInstance().setAccessMode(accessMode);
        AccessMode accessMode = new AccessMode(0,null);
        WCHIoCHubManager.getInstance().setAccessMode(accessMode);

        //配置参数
        InitConfig initConfig = new InitConfig.Builder()
                .maxConnSize(1)
                .receiveBufferSize(1024 * 1024 * 8) //缓冲区大小
                .sendBufferSize(1024 * 1024 * 8) //发送缓冲区大小
                .socketWndSize(50)           //发送串口大小
                .socketWndTimeout(20)      //
                .build();
        WCHIoCHubManager.getInstance().setConfig(initConfig);
        WCHIoCHubManager.getInstance().registerEventListener(eventListener);
        return code;
    }

    //设置本机访问模式
    public static void setAccessMode(AccessMode accessMode){
        WCHIoCHubManager.getInstance().setAccessMode(accessMode);
    }

    //启动IoCHub
    public static void startIoCHub(){
        try {
            WCHIoCHubManager.getInstance().start(SERVER_ADDR);
        } catch (IoCHubException e) {
            LogUtil.d("WCHIoCHubManager start err:"+e.getErrorMessage());
            if (ioCHubConnectStatus != null){
                ioCHubConnectStatus.onStartResult(false,e.getErrorCode());
            }
        }
    }

    //打开会话
    public static void sessionOpen(String id ,String SessionKey) throws IoCHubException {
        WCHIoCHubManager.getInstance().sessionOpen(id,SessionKey);
    }

    //写入数据
    public static void sessionWrite(int id,byte[] data){
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    int ret = WCHIoCHubManager.getInstance().sessionWrite(id,data);
                    if (ret != data.length){
                        LogUtil.d("1.IoCHUB send err>>ret: "+ret+">>data len :"+data.length);
                    }
                } catch (IoCHubException e) {
                    LogUtil.d("1.IoCHUB send exception:" + e.getErrorCode());
                }
            }
        }).start();

    }

    //写入数据
    public static void sessionWrite(byte[] data){
        try {
            if (CurrentSessionAssist.getInstance().getIoCHubSessionBean() == null){
                return;
            }
            int ret = WCHIoCHubManager.getInstance().sessionWrite(CurrentSessionAssist.getInstance().getIoCHubSessionBean().getSessionFD(),data);
            if (ret != data.length){
                LogUtil.d("1.IoCHUB send err>>ret: "+ret+">>data len :"+data.length);
            }
        } catch (IoCHubException e) {
            LogUtil.d("1.IoCHUB send exception:" + e.getErrorCode());
        }

    }



    //获取本机NodeOD
    public static String getLocalID(){
        return WCHIoCHubManager.getInstance().getLocalID();
    }
    //关闭会话
    public static void sessionClose(int id){
        WCHIoCHubManager.getInstance().sessionClose(id);
        handelSessionClose(id);
    }

    public static void stop(){
        WCHIoCHubManager.getInstance().stop();
        CurrentSessionAssist.getInstance().stopIocHub();

    }

    private static final EventListener eventListener = new EventListener() {
        @Override
        public void onStartResult(boolean b, int i) {
            CurrentSessionAssist.getInstance().setStartIoCHub(b);
            //启动 IoCHub 结果回调；
            if (ioCHubConnectStatus != null){
                ioCHubConnectStatus.onStartResult(b,i);
            }
        }

        @Override
        public void onSessionOpenSuccess(int i, String s) {
            //打开会话成功；
            CurrentSessionAssist.getInstance().setIoCHubSessionBean(new IoCHubSessionBean(i,s));
            int type = WCHIoCHubManager.getInstance().getTransferType(i);
            CurrentSessionAssist.getInstance().getIoCHubSessionBean().setSessionType(type);
            if (ioCHubConnectStatus != null){
                ioCHubConnectStatus.onSessionOpenSuccess(i,s);
            }

        }

        @Override
        public void onSessionOpenFailure(String s, int i) {
            //打开会话失败
            if (ioCHubConnectStatus != null){
                ioCHubConnectStatus.onSessionOpenFailure(s,i);
            }
        }

        @Override
        public void onSessionRead(int i, int i1) {
            if (CurrentSessionAssist.getInstance().getIoCHubSessionBean() == null){
                return;
            }
            if(i != CurrentSessionAssist.getInstance().getIoCHubSessionBean().getSessionFD()){
                return;
            }
            LogUtil.d("数据可读........");
            byte[] data = new byte[i1];
            try {
                int ret = WCHIoCHubManager.getInstance().sessionRead(i,data,i1);
                if (ret != 0){
//                    LogUtil.d("读取数据长度"+ FormatUtil.bytesToHexString(data));
                    if (sessionDataCallback != null){
//                        LogUtil.d("sessionDataCallback 不为空");
                        sessionDataCallback.onSessionData(data);
                    } else {
                        LogUtil.d("sessionDataCallback 为空");
                    }
                }
            } catch (IoCHubException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onSessionTransferType(int i, int i1) {
            //更新类型
            if (CurrentSessionAssist.getInstance().getIoCHubSessionBean().getSessionFD() == i ){
                CurrentSessionAssist.getInstance().getIoCHubSessionBean().setSessionType(i1);
            }
            //会话传输类型改变。
            if (ioCHubConnectStatus != null){
                ioCHubConnectStatus.onSessionTransferType(i,i1);
            }

        }

        @Override
        public void onSessionException(int i) {
            //会话状态异常。
            if (ioCHubConnectStatus != null){
                ioCHubConnectStatus.onSessionException(i);
            }

        }

        @Override
        public void onSessionClose(int i, String s) {
            handelSessionClose( i);


        }



        @Override
        public void onException(int i) {
            if (ioCHubConnectStatus != null){
                ioCHubConnectStatus.onException(i);
            }

        }
    };

    private  static  void handelSessionClose(int id) {
        if (CurrentSessionAssist.getInstance().getIoCHubSessionBean() != null){
            if (CurrentSessionAssist.getInstance().getIoCHubSessionBean().getSessionFD() == id ){
                CurrentSessionAssist.getInstance().setIoCHubSessionBean(null);
                CurrentSessionAssist.getInstance().getDeviceInfoBeanList().clear();
                //会话被关闭。
                if (ioCHubConnectStatus != null){
                    ioCHubConnectStatus.onSessionClose();
                }

            }
        }

    }

    public static IoCHubConnectStatus getIoCHubConnectStatus() {
        return ioCHubConnectStatus;
    }

    public static void setIoCHubConnectStatus(IoCHubConnectStatus ioCHubConnectStatus) {
        IoCHubManager.ioCHubConnectStatus = ioCHubConnectStatus;
    }

    //包接收处理回调
    public static void setPackageDealCallback(SessionDataCallback callback){
        LogUtil.d("设置packageDealCallback");
        sessionDataCallback = callback;
    }


}
