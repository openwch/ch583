package cn.wch.wchiochubgwtest;

public class Global {
    public static final int DEVICE_TYPE_BLE = 1;  //BLE设备

    public static final byte IOCHUB_GATEWAY_COMM = 0x02;      //数据通讯

    public static final byte DEVICE_CMD_LIGHT = 0x01;  //灯光控制ID
    public static final byte DEVICE_CMD_SOCKET = 0x02;      //开关控制ID
}
