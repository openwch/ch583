package cn.wch.wchiochubgwtest.util;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class FormatUtil {
    public static String bytesToHexString(byte[] bArr) {
        if (bArr == null || bArr.length==0)
            return "";
        StringBuffer sb = new StringBuffer(bArr.length);
        String sTmp;
        for (int i = 0; i < bArr.length; i++) {
            sTmp = Integer.toHexString(0xFF & bArr[i]);
            if (sTmp.length() < 2) {
                sb.append(0);
            }
            sb.append(sTmp.toUpperCase());
            if (i != (bArr.length - 1)){
                sb.append(" ");
            }
        }
        return sb.toString();
    }

    public static byte[] macStringToBytes(String macStr) {
        if (macStr == null || macStr.length() != 12) {
            throw new IllegalArgumentException("MAC地址必须是12位十六进制字符串");
        }
        byte[] bytes = new byte[6];
        for (int i = 0; i < 6; i++) {
            int offset = i * 2;
            String hexPair = macStr.substring(offset, offset + 2);
            try {
                bytes[i] = (byte) Integer.parseInt(hexPair, 16);
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("无效的十六进制字符: " + hexPair);
            }
        }
        return bytes;
    }

    //bytes --> short 大端
    public static short bytesToShortBigEndian(byte[] bytes, int start){
        byte[] value = new byte[2];
        System.arraycopy(bytes,start,value,0,2);
        // 创建一个ByteBuffer对象并设置其字节顺序为小端模式
        ByteBuffer buffer = ByteBuffer.allocate(2);
        buffer.order(ByteOrder.BIG_ENDIAN);
        buffer.put(value);
        buffer.flip();
        // 从ByteBuffer中读取short类型的值
        return buffer.getShort();
    }

    public static String bytesToMacString(byte[] bytes) {
        StringBuilder macBuilder = new StringBuilder();
        for (int i = 0; i < 6; i++) {
            // 将字节转为无符号整数（0~255）
            int unsignedByte = bytes[i] & 0xFF;
            // 格式化为两位十六进制（大写），不足补零
            String hex = String.format("%02X", unsignedByte);
            macBuilder.append(hex);
            if (i < 5) {
                macBuilder.append(":");
            }
        }
        return macBuilder.toString();
    }

}
