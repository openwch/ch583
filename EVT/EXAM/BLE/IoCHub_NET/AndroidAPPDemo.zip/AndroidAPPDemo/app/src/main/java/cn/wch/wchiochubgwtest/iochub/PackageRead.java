package cn.wch.wchiochubgwtest.iochub;

import static cn.wch.wchiochubgwtest.Global.IOCHUB_GATEWAY_COMM;

import android.os.Handler;
import android.os.Looper;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import cn.wch.wchiochubgwtest.callback.SessionDataCallback;
import cn.wch.wchiochubgwtest.util.FormatUtil;

public class PackageRead {

    private static ValidDataCallback validDataCallback;

    public static void setValidDataCallback(ValidDataCallback callback){
        validDataCallback = callback;
    }
    public static void startPackageRead(){
        IoCHubManager.setPackageDealCallback(sessionDataCallback);
    }
    //临时存放数据的数组
    private static byte[] tmpBytes;
    private static final SessionDataCallback sessionDataCallback = new SessionDataCallback() {
        @Override
        public void onSessionData(byte[] data) {
//            LogUtil.d("网络接收数据:" + FormatUtil.bytesToHexString(data));
            if (tmpBytes == null){
                getCompilePackage(data);
            } else {
                byte[] value = new byte[data.length + tmpBytes.length];
                System.arraycopy(tmpBytes,0,value,0,tmpBytes.length);
                System.arraycopy(data,0,value,tmpBytes.length,data.length);
                tmpBytes = null;   //组合成功后，tmpBytes的数据已被利用，可直接置空
                getCompilePackage(value);
            }
        }
    };

    //根据协议获取完整数据包
    private static void getCompilePackage(byte[] buffer){
        int offset = 0;
        int bufferLength = buffer.length;
        while (offset < bufferLength) {
            int remainLen = buffer.length - offset;  //计算Buffer中剩余可用长度
            if (6 < remainLen) {
                //剩余长度足够找到长度字段
                if (buffer[offset] != 0x55 || buffer[offset + 1] != (byte) 0xAA) {
                    //head未找到,将缓冲区offset向后偏移1个字节
                    offset++;
                } else {
                    //头找到了
                    if (buffer[offset + 2] != IOCHUB_GATEWAY_COMM) {
                        //命令码不对应,从命令码处截断，重新寻找
                        offset += 2;
                    } else {
                        //命令码正确
                        //保留字节跳过  offset+3
                        short pkgLen = FormatUtil.bytesToShortBigEndian(buffer, offset + 4);
                        if (pkgLen <= 5) {
                            //长度无效,从3开始跳转,防止从保留字节开始是新的头
                            offset += 3;
                        } else {
                            //长度有效
                            if ((pkgLen + 2) < remainLen) {
                                byte[] data = Arrays.copyOfRange(buffer, offset, offset + pkgLen + 2);
                                //校验包
                                if (!checkPackage(data)) {
                                    offset += 4; //从长度的那一字节再次轮询查找
                                } else {
                                    //添加数据队列
                                    dealWithData(data);
                                    offset += (pkgLen + 2);
                                }
                            } else if ((pkgLen + 2) == remainLen) {
                                byte[] data = Arrays.copyOfRange(buffer, offset, offset + remainLen);
                                if (!checkPackage(data)) {
                                    offset += 4; //从长度的那一字节再次轮询查找
                                } else {
                                    //添加数据队列
                                    dealWithData(data);
                                    offset += (pkgLen + 2);
                                }
                            } else {
                                tmpBytes = null;
                                tmpBytes = Arrays.copyOfRange(buffer, offset, offset + remainLen);
                                offset += remainLen;
                            }
                        }
                    }
                }
            } else {
                //剩余长度不足，保存
                tmpBytes = null;
                tmpBytes = Arrays.copyOfRange(buffer, offset, offset + remainLen);
                offset += remainLen;
            }
        }
    }

        //包校验
        private static boolean checkPackage(byte[] data){
            byte sum = 0;
            for (int i = 0; i < data.length - 1; i++){
                sum += data[i];
            }
            return sum == data[data.length - 1];
        }

        private static Frame getFrame(byte[] data){
            if (data.length<7){
                return null;
            }
            int cmd = data[2];
            byte[] value = Arrays.copyOfRange(data,6,data.length-1);
            //设备类型
            int devType = FormatUtil.bytesToShortBigEndian(value,0);
            //唯一标识
            byte[] identifyBytes = Arrays.copyOfRange(value,4,12);
            String mac = FormatUtil.bytesToMacString(identifyBytes);
            //数据
            byte[] buffer = Arrays.copyOfRange(value,14,value.length);
            return  new Frame(cmd,mac,devType,buffer);
        }
    //数据处理
    private static void dealWithData(byte[] value) {
//        LogUtil.d("调试处理数据:" + FormatUtil.bytesToHexString(value));
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                Frame frame = getFrame(value);
                if(frame == null){
                    return;
                }
                switch (frame.getCmd()){
                    case IOCHUB_GATEWAY_COMM:
                        dealWithDevData(frame.getMac(), frame.getPayload());
                        if (validDataCallback != null){
                            validDataCallback.onData(frame.getMac());
                        }
                        break;
                    default:break;
                }
            }


        });
    }
    //处理设备数据
    //处理设备数据，命令字节叫啥
    private static void dealWithDevData(String mac,byte[] buffer) {
        List<DevicePacket> packets = parsePacket(buffer);
        for (DevicePacket devicePacket :packets){
            if (devicePacket.getDpId() == 1){
                boolean state = (devicePacket.getDpValue()[0] == 1);
                if (validDataCallback != null){
                    validDataCallback.onLightState(mac,state);
                }
            } else if (devicePacket.getDpId() == 2) {
                boolean state = (devicePacket.getDpValue()[0] == 1);
                if (validDataCallback != null){
                    validDataCallback.onSocketState(mac,state);
                }
            }
        }
    }

    public static List<DevicePacket> parsePacket(byte[] byteArray) {
        List<DevicePacket> packets = new ArrayList<>(); // 存储解析出的数据包
        int i = 0; // 当前字节索引
        while (i < byteArray.length - 1) {
            // 检查是否为包头
            if ((byteArray[i] & 0xFF) == 0x33 && (byteArray[i + 1] & 0xFF) == 0xCC) {
                // 跳过包头
                i += 2;

                // 检查是否有足够的字节来解析后续字段
                if (i + 6 > byteArray.length) { // 至少需要 dp_id(1B) + dp_type(1B) + dp_length(2B) + 校验和(1B)
                    break;
                }

                // 解析 dp_id 和 dp_type
                int dpId = byteArray[i] & 0xFF;
                int dpType = byteArray[i + 1] & 0xFF;
                i += 2;

                // 解析 dp_length (2字节，大端序)
                int dpLength = ((byteArray[i] & 0xFF) << 8) | (byteArray[i + 1] & 0xFF);
                i += 2;

                // 检查是否有足够的字节来解析 dp_value 和校验和
                if (i + dpLength + 1 > byteArray.length) {
                    break;
                }

                // 解析 dp_value
                byte[] dpValue = new byte[dpLength];
                System.arraycopy(byteArray, i, dpValue, 0, dpLength);
                i += dpLength;

                // 解析校验和
                int checksum = byteArray[i] & 0xFF;
                i++;

//                // 验证校验和（假设校验和是所有前面字节的累加和取低8位）
//                int expectedChecksum = calculateChecksum(byteArray, i - (6 + dpLength), i - 1);
//                if (checksum != expectedChecksum) {
//                    System.out.println("校验和错误，丢弃数据包：dp_id=" + dpId + ", dp_type=" + dpType);
//                    continue;
//                }

                // 将解析结果存储到Packet对象中
                packets.add(new DevicePacket(dpId, dpType, dpLength, dpValue, checksum));
            } else {
                // 如果不是包头，继续查找
                i++;
            }
        }

        return packets;
    }
    public interface ValidDataCallback{
        void onData(String mac);
        void onLightState(String mac,boolean state);
        void onSocketState(String mac,boolean state);

    }
}
