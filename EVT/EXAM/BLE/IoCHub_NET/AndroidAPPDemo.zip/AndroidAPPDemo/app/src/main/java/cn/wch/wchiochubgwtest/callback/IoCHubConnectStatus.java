package cn.wch.wchiochubgwtest.callback;

public interface IoCHubConnectStatus {
    void onStartResult(boolean result, int code);

    void onSessionOpenSuccess(int sessionFd, String nodeID);

    void onSessionOpenFailure(String nodeID, int code);

    void onSessionTransferType(int sessionFd, int type);

    void onSessionException(int sessionFd);

    void onSessionClose();

    void onException(int code);
}

