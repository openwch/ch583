package cn.wch.wchiochubgwtest.callback;

public interface SessionDataCallback {
    void onSessionData(byte[] data);

}
