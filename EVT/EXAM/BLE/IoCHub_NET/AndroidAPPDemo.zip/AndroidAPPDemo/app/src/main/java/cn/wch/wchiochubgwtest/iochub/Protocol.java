package cn.wch.wchiochubgwtest.iochub;

import static cn.wch.wchiochubgwtest.Global.IOCHUB_GATEWAY_COMM;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;

import cn.wch.wchiochubgwtest.util.FormatUtil;

public class Protocol {
    //获取通讯数据帧
    public static byte[] getIoCHubCommData(byte[] data, int devType, int inter, String mac){
        String macStr = mac.replace(":","").trim();
        ByteBuffer byteBuffer = ByteBuffer.allocate(14 + data.length);
        byteBuffer.order(ByteOrder.BIG_ENDIAN);
        //设备类型
        byteBuffer.putShort((short) devType);
        //接口类型
        byteBuffer.put(new byte[]{0x00,0x00});
        //设备标识
        byteBuffer.put(Arrays.copyOf(FormatUtil.macStringToBytes(macStr),8));
        //数据长度
        byteBuffer.putShort((short) data.length);
        //数据内容
        byteBuffer.put(data);
        byteBuffer.flip();
        return getProtocolHead(IOCHUB_GATEWAY_COMM, byteBuffer.array());
    }

    //获取头数据
    private static byte[] getProtocolHead(byte cmd, byte[] value){
        ByteBuffer byteBuffer = ByteBuffer.allocate(7 + value.length);
        byteBuffer.order(ByteOrder.BIG_ENDIAN);
        byteBuffer.put(new byte[]{0x55, (byte) 0xAA});
        byteBuffer.put(cmd);
        byteBuffer.put((byte) 0x00);
        byteBuffer.putShort((short) (5 + value.length));
        byteBuffer.put(value);
        byteBuffer.flip();
        return getCompleteData(byteBuffer.array());
    }

    //添加校验
    public static byte[] getCompleteData(byte[] data){
        byte sum = 0;
        for (byte datum : data) {
            sum += datum;
        }
        sum = (byte) (sum & 0xFF);
        byte[] value = Arrays.copyOf(data,data.length);
        value[value.length - 1] = sum;
        return value;
    }
}
