package cn.wch.wchiochubgwtest.iochub;

import static cn.wch.wchiochubgwtest.Global.DEVICE_TYPE_BLE;

import cn.wch.wchiochubgwtest.util.LogUtil;
import kotlin.text.UStringsKt;

public class PackageWrite {

    //向对端发送当前端的系统平台
    public static void sendData(String Mac,byte[] data) {
        byte[] buffer = Protocol.getIoCHubCommData(data,DEVICE_TYPE_BLE,0,Mac);
        IoCHubManager.sessionWrite(buffer);
        LogUtil.d("发送:" +"data");
    }


    //向对端发送当前端的系统平台
    public static void sendDevLightState(String Mac,boolean state) {
        int offset = 0;
        byte[] value  = new byte[8];
        //handle
        value[offset++] =(byte) 0xBB;
        value[offset++] = (byte)0x44;
        //操作类型
        value[offset++] = (byte)0x01;
        //数据类型
        value[offset++] = (byte)0x01;
        //len
        value[offset++] = (byte)0x00;
        value[offset++] = (byte)0x01;
        if (state){
            value[offset++] = (byte)0x01;
        }else {
            value[offset++] = (byte)0x00;
        }
        byte[] data = Protocol.getCompleteData(value);
        byte[] buffer = Protocol.getIoCHubCommData(data,DEVICE_TYPE_BLE,0,Mac);
        IoCHubManager.sessionWrite(buffer);
        LogUtil.d("发送:" +"data");
    }
}
