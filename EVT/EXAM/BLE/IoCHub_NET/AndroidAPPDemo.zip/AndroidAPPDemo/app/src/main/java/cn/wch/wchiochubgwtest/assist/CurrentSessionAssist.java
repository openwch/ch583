package cn.wch.wchiochubgwtest.assist;

import java.util.ArrayList;
import java.util.List;

import cn.wch.wchiochubgwtest.bean.DeviceInfoBean;
import cn.wch.wchiochubgwtest.bean.IoCHubSessionBean;

/**
 * 当前连接的网关信息
 */
public class CurrentSessionAssist {

    private static CurrentSessionAssist currentSessionAssist;

    private boolean isInitIoCHubSuccess = false;  //是否初始化成功
    private boolean isStartIoCHub = false;  //是否启动IoCHub服务
    private String localNodeID;   //当前IoCHub设备节点ID
    private IoCHubSessionBean ioCHubSessionBean; //连接的会话信息,目前只支持一个连接
    private List<DeviceInfoBean> deviceInfoBeanList = new ArrayList<>(); //网关连接的设备列表


    public static CurrentSessionAssist getInstance(){
        if(currentSessionAssist == null){
            synchronized (CurrentSessionAssist.class){
                currentSessionAssist = new CurrentSessionAssist();
            }
        }
        return currentSessionAssist;
    }


    public IoCHubSessionBean getIoCHubSessionBean() {
        return ioCHubSessionBean;
    }

    public void setIoCHubSessionBean(IoCHubSessionBean ioCHubSessionBean) {
        this.ioCHubSessionBean = ioCHubSessionBean;
    }


    public boolean isInitIoCHubSuccess() {
        return isInitIoCHubSuccess;
    }

    public void setInitIoCHubSuccess(boolean initIoCHubSuccess) {
        isInitIoCHubSuccess = initIoCHubSuccess;
    }

    public boolean isStartIoCHub() {
        return isStartIoCHub;
    }

    public void setStartIoCHub(boolean startIoCHub) {
        isStartIoCHub = startIoCHub;
    }

    public String getLocalNodeID() {
        return localNodeID;
    }

    public void setLocalNodeID(String localNodeID) {
        this.localNodeID = localNodeID;
    }
    public void addDeviceInfoBeanList(DeviceInfoBean deviceInfoBean) {
        deviceInfoBeanList.add(deviceInfoBean);
    }
    public List<DeviceInfoBean> getDeviceInfoBeanList() {
        return deviceInfoBeanList;
    }
    public void  clearDeviceInfoBeanList() {
        deviceInfoBeanList.clear();
    }
    public void  stopIocHub(){
        isStartIoCHub = false;
        ioCHubSessionBean = null;
        clearDeviceInfoBeanList();

    }

}
