package cn.wch.wchiochubgwtest.ui;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;

import cn.wch.wchiochubgwtest.R;
import cn.wch.wchiochubgwtest.databinding.SessionConnectDialogBinding;
import cn.wch.wchiochubgwtest.util.ToastUtil;

public class ConnectSessionDialog extends Dialog {
    private Context context;
    private EditText targetNodeID,targetSecret;
    private Button openSessionBtn,closeBtn;
    private OpenSessionCallback openSessionCallback;



    public static ConnectSessionDialog newInstance(Context context) {
        ConnectSessionDialog connectSessionDialog = new ConnectSessionDialog(context);
        return connectSessionDialog;
    }
    public ConnectSessionDialog(@NonNull Context context) {
        super(context);
        this.context = context;

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.session_connect_dialog);
        bindView();
        setViewClickListener();



    }


    //绑定控件
    private void bindView() {
        targetNodeID = findViewById(R.id.targetNodeID);
        targetSecret = findViewById(R.id.targetSecret);
        openSessionBtn = findViewById(R.id.openSessionBtn);
        closeBtn = findViewById(R.id.closeBtn);
    }
    //控件回调
    private void setViewClickListener() {
        //打开会话
        openSessionBtn.setOnClickListener(v -> {

            openSession();

        });
        closeBtn.setOnClickListener(v -> {
            dismiss();
        });
    }

    private void openSession() {
        if (!checkInput()){
            return;
        }
        String nodeID = targetNodeID.getText().toString();
        String secret = null;
        if (targetSecret.getText().length() != 0){
            secret = targetSecret.getText().toString();
        }
        if (openSessionCallback != null){
            openSessionCallback.onSessionOpen(nodeID,secret);

        }
    }

    private boolean checkInput(){
        if (targetNodeID.getText().length() == 0){
            ToastUtil.show(context,context.getResources().getString(R.string.not_input_target_nodeID));
            return false;
        }
        if (targetNodeID.getText().length() != 16){
            ToastUtil.show(context,context.getResources().getString(R.string.target_nodeID_not_match));
            return false;
        }
        if (targetSecret.getText().length() > 8){
            ToastUtil.show(context,context.getResources().getString(R.string.target_secret_not_match));
            return false;
        }
        return true;
    }

    public void setOpenSessionCallback(OpenSessionCallback callback){
        this.openSessionCallback = callback;
    }
    public interface OpenSessionCallback{
        void onSessionOpen(String id ,String SessionKey);
        void onClose();
    }

}
