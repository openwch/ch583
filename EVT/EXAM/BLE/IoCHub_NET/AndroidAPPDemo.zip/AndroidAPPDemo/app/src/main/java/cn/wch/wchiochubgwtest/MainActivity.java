package cn.wch.wchiochubgwtest;

import static cn.wch.wchiochubgwtest.Global.DEVICE_CMD_LIGHT;
import static cn.wch.wchiochubgwtest.Global.DEVICE_CMD_SOCKET;
import static cn.wch.wchiochubgwtest.Global.DEVICE_TYPE_BLE;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import java.sql.Date;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.Objects;
import java.util.Timer;
import java.util.TimerTask;

import cn.wch.iochublibrary.error.IoCHubException;
import cn.wch.wchiochubgwtest.adapter.ConnectDevAdapter;
import cn.wch.wchiochubgwtest.assist.CurrentSessionAssist;
import cn.wch.wchiochubgwtest.bean.DeviceInfoBean;
import cn.wch.wchiochubgwtest.callback.IoCHubConnectStatus;
import cn.wch.wchiochubgwtest.databinding.ActivityMainBinding;
import cn.wch.wchiochubgwtest.iochub.IoCHubManager;
import cn.wch.wchiochubgwtest.iochub.PackageRead;
import cn.wch.wchiochubgwtest.iochub.PackageWrite;
import cn.wch.wchiochubgwtest.ui.ConnectSessionDialog;
import cn.wch.wchiochubgwtest.util.FormatUtil;
import cn.wch.wchiochubgwtest.util.LogUtil;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
     private Menu mainMenu;

     private boolean isTest;
    private boolean isSucceed;
    private long sendSize;
    private long lastSecondSendSize;//用于计算速度
    private long receiveSize;
    private long lastSecondReceiveSize;//用于计算速度

    //收发大小、速度显示定时器
    private boolean isSpeedTimer = false;
    private Timer speedTimer;
    private TimerTask speedTimerTask;

    private ConnectDevAdapter connectDevAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        initTool();
        initPara();
        setViewClickListener();
        initIocHub();
    }


    //控件操作回调
    private void setViewClickListener() {

        binding.sessionInfoItem.closeSessionText.setOnClickListener(v -> {
            closeSession();
        });
        binding.logInfoItem.clearLogText.setOnClickListener(v -> {
            binding.logInfoItem.infoText.setText("");
        });
    }



    private void initIocHub() {
        PackageRead.startPackageRead();
        PackageRead.setValidDataCallback(validDataCallback);
        IoCHubManager.setIoCHubConnectStatus(ioCHubConnectStatus);
        int code = IoCHubManager.initIoCHub(MainActivity.this);
        if (code != 0){
            showToast("初始化库失败："+code);
            return;
        }
        CurrentSessionAssist.getInstance().setInitIoCHubSuccess(true);

    }

    //初始化参数
    private void initPara() {
        connectDevAdapter = new ConnectDevAdapter(CurrentSessionAssist.getInstance().getDeviceInfoBeanList(),connectDevAdapterCallback);
        binding.devListItem.connectDevListRv.setLayoutManager(new LinearLayoutManager(MainActivity.this,LinearLayoutManager.VERTICAL,false));
        binding.devListItem.connectDevListRv.setAdapter(connectDevAdapter);
    }

    //初始化标题栏
    private void initTool() {
        setSupportActionBar(binding.mainToolbar);
        Objects.requireNonNull(getSupportActionBar()).setDisplayShowTitleEnabled(true);
    }
    /************************ menu start ************************/

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        this.mainMenu = menu;
        setMenu(false);
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId();
        if (itemId == R.id.add){
            //添加会话
            if (CurrentSessionAssist.getInstance().isStartIoCHub()){
                addSession();
            }else {
                showToast("未启动服务");
            }

        } else if (itemId == R.id.start){
            //启动服务

            if (!CurrentSessionAssist.getInstance().isStartIoCHub()){
                startIocHub();
            }

        } else if (itemId == R.id.stop) {

//            clearAllSession();
            stopIocHub();
        }
        return super.onOptionsItemSelected(item);
    }
    /************************ call back start  ************************/
    private final IoCHubConnectStatus ioCHubConnectStatus = new IoCHubConnectStatus() {
        @Override
        public void onStartResult(boolean result, int code) {
            if (!result){
                showToast("启动服务失败："+code);
                addLogInfo("启动服务失败："+code);
            }else {
                showToast("启动服务成功");
                addLogInfo("启动服务成功");
                setMenu(true);
            }
        }

        @Override
        public void onSessionOpenSuccess(int sessionFd, String nodeID) {
            showToast("会话打开成功："+nodeID);
            addLogInfo("会话打开成功："+nodeID);
            updateSessionInfo();

        }

        @Override
        public void onSessionOpenFailure(String nodeID, int code) {
            showToast("会话打开失败："+code);
            addLogInfo("会话打开失败："+code);

        }

        @Override
        public void onSessionTransferType(int sessionFd, int type) {
            addLogInfo("会话类型改变："+type);
            updateSessionInfo();
        }

        @Override
        public void onSessionException(int sessionFd) {
            showToast("会话异常");
            addLogInfo("会话异常");

        }

        @Override
        public void onSessionClose() {
            //会话关闭
            updateSessionInfo();
            upDateDeviceList();
        }

        @Override
        public void onException(int code) {
            showToast("服务异常："+code);
            addLogInfo("服务异常："+code);

        }
    };

    //打开会话回调
    private final ConnectSessionDialog.OpenSessionCallback openSessionCallback = new ConnectSessionDialog.OpenSessionCallback() {
        @Override
        public void onSessionOpen(String id, String SessionKey) {
            sessionOpen(id,SessionKey);
        }

        @Override
        public void onClose() {

        }
    };

    //接受设备回调
    private final PackageRead.ValidDataCallback validDataCallback = new PackageRead.ValidDataCallback() {
        @Override
        public void onData(String mac) {
//            LogUtil.d("接收数据："+ FormatUtil.bytesToHexString(data));
            updateData(mac);
        }

        @Override
        public void onLightState(String mac, boolean state) {
            //灯光状态
            LogUtil.d("灯状态："+state);
            updateLightState( mac,state);
        }
        @Override
        public void onSocketState(String mac, boolean state) {
            LogUtil.d("开关状态："+state);
            updateSocketState(mac,state);
        }


    };

    private final ConnectDevAdapter.ConnectDevAdapterCallback connectDevAdapterCallback = new ConnectDevAdapter.ConnectDevAdapterCallback() {
        @Override
        public void onEnableLightState(String mac, boolean state) {
            PackageWrite.sendDevLightState(mac,state);
        }
    };



    /************************ IoCHub start  ************************/

    //启动服务
    private void startIocHub() {
        if (!CurrentSessionAssist.getInstance().isInitIoCHubSuccess()){
            int code = IoCHubManager.initIoCHub(MainActivity.this);
            if (code != 0){
                showToast("初始化库失败："+code);
                return;
            }
            CurrentSessionAssist.getInstance().setInitIoCHubSuccess(true);

        }
        IoCHubManager.startIoCHub();
    }

    //停止服务
    private void stopIocHub(){
        addLogInfo("停止服务");
        IoCHubManager.stop();
        setMenu(false);
        updateSessionInfo();
        upDateDeviceList();
    }


    //删除会话
    private void closeSession() {
        if (CurrentSessionAssist.getInstance().getIoCHubSessionBean() != null){
            IoCHubManager.sessionClose(CurrentSessionAssist.getInstance().getIoCHubSessionBean().getSessionFD());
        }
    }

    //设置menu的显示和隐藏
    private void setMenu(boolean enable) {
        if (mainMenu == null) {
            return;
        }
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mainMenu.findItem(R.id.start).setVisible(!enable);
                mainMenu.findItem(R.id.stop).setVisible(enable);
            }
        });
    }

    //打开会话
    private void sessionOpen(String id,String SessionKey){
       if (CurrentSessionAssist.getInstance().getIoCHubSessionBean() != null){
           showToast("已有会话存在");
           return;
       }
        try {
            IoCHubManager.sessionOpen(id,SessionKey);
        } catch (IoCHubException e) {
            showToast("打开会话异常"+e.getErrorMessage());
        }
    }


    //添加会话
    private void addSession() {
        ConnectSessionDialog connectSessionDialog = ConnectSessionDialog.newInstance(MainActivity.this);
        connectSessionDialog.setCancelable(false);
        connectSessionDialog.setOpenSessionCallback(openSessionCallback);
        connectSessionDialog.show();
    }

    //更新会话信息
    private void updateSessionInfo(){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if ( CurrentSessionAssist.getInstance().getIoCHubSessionBean() == null){
                    binding.sessionInfoItem.nodeIDText.setText("");
                    binding.sessionInfoItem.sessionTypeText.setText("");
                    binding.sessionInfoItem.sessionStateText.setText("");

                }else {
                    binding.sessionInfoItem.nodeIDText.setText(
                            CurrentSessionAssist.getInstance().getIoCHubSessionBean().getNodeID());
                    binding.sessionInfoItem.sessionTypeText.setText(getSessionTypeStr(CurrentSessionAssist.getInstance().getIoCHubSessionBean().getSessionType()));

                    if (CurrentSessionAssist.getInstance().getIoCHubSessionBean().isSessionException()){
                        binding.sessionInfoItem.sessionStateText.setText("正常");
                    }else {
                        binding.sessionInfoItem.sessionStateText.setText("异常");
                    }
                }
            }
        });
    }

    //获取会话类型字符串
    private String getSessionTypeStr(int type){
        String str;
        if (type == 0x01){  //P2P
            str = "P2P";
        } else if (type == 0x02){  //转发
            str = "转发";

        } else if (type == 0x03){  //局域网
            str = "局域网";

        }else {
            str = "未知";
        }
        return str;
    }

    //更新灯光状态
    private void updateLightState(String mac, boolean state) {
        DeviceInfoBean  deviceInfoBean  = getDeviceInfoBean(mac);
        if (deviceInfoBean == null){
            return;
        }
        if (deviceInfoBean.isLightState() != state){
            deviceInfoBean.setLightState(state);
            connectDevAdapter.updateState(mac,DEVICE_CMD_LIGHT,state);
        }

    }
    //更新灯光状态
    private void updateSocketState(String mac, boolean state) {
        DeviceInfoBean  deviceInfoBean  = getDeviceInfoBean(mac);
        if (deviceInfoBean == null){
            return;
        }
        if (deviceInfoBean.isSocketState() != state){
            deviceInfoBean.setSocketState(state);
            connectDevAdapter.updateState(mac,DEVICE_CMD_SOCKET,state);
        }

    }
    //Toast
    private void showToast(String message) {
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void addLogInfo(String message){
        if( binding == null){
            return;
        }
        Date currentDate = new Date(System.currentTimeMillis());
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        String formattedDate = sdf.format(currentDate);
        String str = formattedDate + ">>>>"+message+"\n";
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                int ShowSizeMax = 1500;
                if (binding.logInfoItem.infoText.getLineCount() > ShowSizeMax) {
                    String text = binding.logInfoItem.infoText.getText().toString();
                    String newText = text.substring(text.indexOf('\n') + 500); // 删除500行
                    binding.logInfoItem.infoText.setText(newText);
                }
                binding.logInfoItem.infoText.append(str);
                binding.logInfoItem.logScrollView.post(() -> binding.logInfoItem.logScrollView.fullScroll(View.FOCUS_DOWN));
            }
        });
    }

    /************************ data start  ************************/
    private void updateData(String mac) {
        DeviceInfoBean deviceInfoBean = getDeviceInfoBean(mac);
        if (deviceInfoBean == null){
            //还未建立设备
            addDeviceInfoBean(mac);
        }
    }


    //添加设备列表
    private void addDeviceInfoBean(String mac) {
        CurrentSessionAssist.getInstance().addDeviceInfoBeanList(new DeviceInfoBean(DEVICE_TYPE_BLE,mac));
        upDateDeviceList();
    }

    //更新设备列表
    private void upDateDeviceList() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                connectDevAdapter.notifyDataSetChanged();
            }
        });
    }

    //获取连接的字节数
    private DeviceInfoBean getDeviceInfoBean(String mac) {
        for (DeviceInfoBean deviceInfoBean : CurrentSessionAssist.getInstance().getDeviceInfoBeanList()){
            if (deviceInfoBean.getMac().equals(mac)){
                return deviceInfoBean;
            }
        }
        return null;
    }

}