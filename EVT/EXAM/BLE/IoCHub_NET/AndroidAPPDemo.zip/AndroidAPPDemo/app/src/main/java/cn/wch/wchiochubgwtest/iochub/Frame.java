package cn.wch.wchiochubgwtest.iochub;

public class Frame {
    private int cmd;//协议
    private String Mac;
    private int devType;
    private byte[] payload;

    public Frame(int cmd, String mac, int devType, byte[] payload) {
        this.cmd = cmd;
        Mac = mac;
        this.devType = devType;
        this.payload = payload;
    }

    public int getCmd() {
        return cmd;
    }

    public void setCmd(int cmd) {
        this.cmd = cmd;
    }

    public String getMac() {
        return Mac;
    }

    public void setMac(String mac) {
        Mac = mac;
    }

    public byte[] getPayload() {
        return payload;
    }

    public void setPayload(byte[] payload) {
        this.payload = payload;
    }

    public int getDevType() {
        return devType;
    }

    public void setDevType(int devType) {
        this.devType = devType;
    }
}
