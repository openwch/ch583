package cn.wch.blelib.ch583.callback;

public interface RSSIStatus {

    void onRSSI(int rssi, int status);
}
