package cn.wch.blelib.ch583.ota.exception;

public class CH583OTAException extends Exception {
    public CH583OTAException(String message) {
        super(message);
    }
}
