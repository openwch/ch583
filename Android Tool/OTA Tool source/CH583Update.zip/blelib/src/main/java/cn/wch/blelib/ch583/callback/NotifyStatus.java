package cn.wch.blelib.ch583.callback;

public interface NotifyStatus {
    void onData(byte[] data);
}
